package Model;

public class FilaInd {
	
	public int vuelo;
	public String Nombre;
	public double TEL;
	public double TLA;
	public double RET;
	
	public FilaInd(int vuelo, String Nombre, double TEL, double TLA, double RET) {
		this.vuelo=vuelo;
		this.Nombre=Nombre;
		this.TEL=TEL;
		this.TLA=TLA;
		this.RET=RET;
	}
}
