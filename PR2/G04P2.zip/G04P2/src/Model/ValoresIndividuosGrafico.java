package Model;

public class ValoresIndividuosGrafico {
	public double[] fenotipos;
	public double fitness;
	
	public ValoresIndividuosGrafico(double[] fenotipos, double fitness) {
		this.fenotipos=fenotipos;
		this.fitness=fitness;
	}
}
