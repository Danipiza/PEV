package Utils;

public class FuncionException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public FuncionException(String msg) {
		super(msg);
	}

}
